package com.example.demo.enums;

import java.util.function.Function;

/**
 * 根据枚举类构造sql的case when语句
 *
 * @author hyj
 */
public class EnumsBuildSql {
    public static void main(String[] args) {
        String paramsName = "test";
        Function<TestEnum, Object> getCode = (mEnums -> mEnums.getCode());
        Function<TestEnum, String> getMessage = (mEnums -> mEnums.getMessage());

        StringBuilder builder = new StringBuilder();
        builder.append("case ").append(paramsName);

        int maxLength = 0;
        int i = 0;
        for (TestEnum odsCarrierEnum : TestEnum.values()) {
            maxLength = Math.max(getCode.apply(odsCarrierEnum).toString().length(), maxLength);
        }

        for (TestEnum mEnum : TestEnum.values()) {
            if (i++ != 0) {
                builder.append("    ");
                for (int j = 0; j <= paramsName.length(); j++) {
                    builder.append(" ");
                }
            }

            builder.append(" when ");
            for (int j = 0; j < maxLength - getCode.apply(mEnum).toString().length(); j++) {
                builder.append(" ");
            }

            if (getCode.apply(mEnum).getClass() == Integer.class) {
                builder.append(getCode.apply(mEnum));
            } else {
                builder.append("'").append(getCode.apply(mEnum)).append("'");
            }

            builder.append(" then '").append(getMessage.apply(mEnum)).append("'\n");
        }

        for (int j = 0; j <= paramsName.length(); j++) {
            builder.append(" ");
        }
        builder.append("     else ''\n end");
        System.out.println(builder.toString());
    }
}

/**
 * 测试用例
 *
 */
enum TestEnum {
    /** */
    A(1, "AA"),
    /** */
    B(2, "BB"),
    ;

    /** */
    private final Integer code;
    /** */
    private final String message;

    /** */
    TestEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    /** */
    public Integer getCode() {
        return code;
    }

    /** */
    public String getMessage() {
        return message;
    }
}