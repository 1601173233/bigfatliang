package cn.com.toolWeb.vaild;

/**
 * 校验类型（保存）
 *
 * @author jack.huang
 */
public interface Save {

}
