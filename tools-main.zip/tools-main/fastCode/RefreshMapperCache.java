
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.binding.MapperRegistry;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.builder.xml.XMLMapperEntityResolver;
import org.apache.ibatis.executor.keygen.SelectKeyGenerator;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.parsing.XNode;
import org.apache.ibatis.parsing.XPathParser;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Mybatics热部署
 *
 * @author : huangyujie
 * 2019/04/22 14:22:43
 */
@Component
@Slf4j
@AutoConfigureAfter(SqlSessionFactory.class)
public class RefreshMapperCache extends Thread {

    /**
     * mybatis的sessionFactory
     */
    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    /**
     * 扫描包路径配置
     */
    @Value("mapper/**Mapper.xml")
    private String packageSearchPath;

    private Resource[] mapperLocations;

    /**
     * 记录文件是否变化
     */
    private HashMap<String, Long> fileMapping = new HashMap<String, Long>();

    /**
     * 记录发生改变的xml文件名称
     */
    private List<String> changeResourceNameList = new ArrayList<String>();

    /**
     * 是否启动刷新
     */
    private String isRefresh = "true";

    /**
     * 每次执行的间隔
     **/
    private Integer sleepSeconds = 3;

    /**
     * 延迟刷新秒数
     **/
    private Integer delaySeconds = 5;

    private Configuration configuration;

    /**
     * 构造函数
     */
    RefreshMapperCache() {
        // 启动线程
        this.start();
    }

    ;

    /**
     * 初始化方法
     */
    @Override
    public void run() {
        try {
            //延迟执行的时间
            Thread.sleep(delaySeconds * 1000);

            if ("true".equalsIgnoreCase(isRefresh)) {

                while (true) {

                    refreshMapper();

                    //延迟时间
                    Thread.sleep(sleepSeconds * 1000);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 延迟执行的时间
     *
     * @return
     */
    protected Integer getDelaySeconds() {
        return delaySeconds;
    }

    /**
     * 每次执行的间隔
     *
     * @return
     */
    protected Integer getSleepSeconds() {
        return sleepSeconds;
    }

    /**
     * 刷新的函数
     */
    protected void refreshMapper() {
        try {
            configuration = this.sqlSessionFactory.getConfiguration();

            // step.1 扫描文件
            try {
                this.scanMapperXml();
            } catch (IOException e) {
                log.error("packageSearchPath扫描包路径配置错误");
                return;
            }

//            System.out.println("==============刷新前mapper中的内容 start===============");
//            //获取xml中的每个语句的名称即 id = "findUserById";
//            for (String name : configuration.getMappedStatementNames()) {
//                System.out.println(name);
//            }
//            System.out.println("==============刷新前mapper中的内容   end===============");

            //清空被修改过后的文件名称，确保该集合是空的
            changeResourceNameList.clear();

            // step.2 判断是否有文件发生了变化
            if (this.isChanged()) {

                for (Resource resource : mapperLocations) {
                    // step.2.1 清理
                    this.removeConfig(configuration, resource);

                    try {
                        // step.2.2 重新加载
                        XMLMapperBuilder xmlMapperBuilder
                                = new XMLMapperBuilder(resource.getInputStream(),
                                configuration, resource.toString(),
                                configuration.getSqlFragments());
                        xmlMapperBuilder.parse();

//                    	}
                    } catch (IOException e) {
                        System.out.println("mapper文件[" + resource.getFilename() + "]不存在或内容格式不对");
                        continue;
                    }
                }
            }

//            System.out.println("--------------------------刷新后mapper中的内容 start--------------------------");
//            for (String name : configuration.getMappedStatementNames()) {
//                System.out.println(name);
//            }
//            System.out.println("--------------------------刷新后mapper中的内容  end--------------------------");
        } catch (Exception e) {
            System.out.println("****************刷新缓存异常： " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void removeConfig(Configuration configuration, Resource resource) throws NoSuchFieldException, IllegalAccessException, IOException, ClassNotFoundException {
        boolean isSupper = configuration.getClass().getSuperclass() == Configuration.class;
        Field loadedResourcesField = isSupper ? configuration.getClass().getSuperclass().getDeclaredField("loadedResources")
                : configuration.getClass().getDeclaredField("loadedResources");
        loadedResourcesField.setAccessible(true);
        Set loadedResourcesSet = ((Set) loadedResourcesField.get(configuration));
        XPathParser xPathParser = new XPathParser(resource.getInputStream(), true, configuration.getVariables(),
                new XMLMapperEntityResolver());
        XNode context = xPathParser.evalNode("/mapper");
        String namespace = context.getStringAttribute("namespace");
        Field field = MapperRegistry.class.getDeclaredField("knownMappers");
        field.setAccessible(true);
        Map mapConfig = (Map) field.get(configuration.getMapperRegistry());
        Collection<String> mappedStatementNames = configuration.getMappedStatementNames();

        mapConfig.remove(Resources.classForName(namespace));
        loadedResourcesSet.remove(resource.toString());
        configuration.getCacheNames().remove(namespace);

        cleanParameterMap(context.evalNodes("/mapper/parameterMap"), namespace);
        cleanResultMap(context.evalNodes("/mapper/resultMap"), namespace);
        cleanKeyGenerators(context.evalNodes("insert|update|select"), namespace);
        cleanSqlElement(context.evalNodes("/mapper/sql"), namespace);
    }


    /**
     * 清理parameterMap
     *
     * @param list
     * @param namespace
     */
    private void cleanParameterMap(List<XNode> list, String namespace) {
        for (XNode parameterMapNode : list) {
            String id = parameterMapNode.getStringAttribute("id");
            configuration.getParameterMaps().remove(namespace + "." + id);
        }
    }

    /**
     * 清理resultMap
     *
     * @param list
     * @param namespace
     */
    private void cleanResultMap(List<XNode> list, String namespace) {
        for (XNode resultMapNode : list) {
            String id = resultMapNode.getStringAttribute("id", resultMapNode.getValueBasedIdentifier());
            configuration.getResultMapNames().remove(id);
            configuration.getResultMapNames().remove(namespace + "." + id);
            clearResultMap(resultMapNode, namespace);
        }
    }

    private void clearResultMap(XNode xNode, String namespace) {
        for (XNode resultChild : xNode.getChildren()) {
            if ("association".equals(resultChild.getName()) || "collection".equals(resultChild.getName())
                    || "case".equals(resultChild.getName())) {
                if (resultChild.getStringAttribute("select") == null) {
                    configuration.getResultMapNames().remove(
                            resultChild.getStringAttribute("id", resultChild.getValueBasedIdentifier()));
                    configuration.getResultMapNames().remove(
                            namespace + "." + resultChild.getStringAttribute("id", resultChild.getValueBasedIdentifier()));
                    if (resultChild.getChildren() != null && !resultChild.getChildren().isEmpty()) {
                        clearResultMap(resultChild, namespace);
                    }
                }
            }
        }
    }

    /**
     * 清理selectKey
     *
     * @param list
     * @param namespace
     */
    private void cleanKeyGenerators(List<XNode> list, String namespace) {
        Collection<MappedStatement> mappedStatements = configuration.getMappedStatements();
        List<MappedStatement> objects = Lists.newArrayList();

        for (XNode context : list) {
            String id = context.getStringAttribute("id");
            configuration.getKeyGeneratorNames().remove(id + SelectKeyGenerator.SELECT_KEY_SUFFIX);
            configuration.getKeyGeneratorNames().remove(namespace + "." + id + SelectKeyGenerator.SELECT_KEY_SUFFIX);

            Iterator<MappedStatement> it = mappedStatements.iterator();
            while (it.hasNext()){
                Object object=it.next();

                if(object instanceof org.apache.ibatis.mapping.MappedStatement) {
                    MappedStatement mappedStatement=(MappedStatement)object;
                    if (mappedStatement.getId().equals(namespace + "." + id)) {
                        objects.add(mappedStatement);
                    }
                }

            }
        }

        mappedStatements.removeAll(objects);
    }

    /**
     * 清理sql节点缓存
     *
     * @param list
     * @param namespace
     */
    private void cleanSqlElement(List<XNode> list, String namespace) {
        for (XNode context : list) {
            String id = context.getStringAttribute("id");
            configuration.getSqlFragments().remove(id);
            configuration.getSqlFragments().remove(namespace + "." + id);
        }
    }

    /**
     * 扫描xml文件所在的路径
     *
     * @throws IOException
     */
    private void scanMapperXml() throws IOException {
        //这个东西被我改了，这里如果注释掉就可以动态新增.xml文件了~
        if (this.mapperLocations == null || this.mapperLocations.length == 0) {
            String paths[] = packageSearchPath.split(";");
            List<Resource> mapperLocationList = new ArrayList<>();
            for(String path : paths){
                mapperLocationList.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources(path)));
            }

            this.mapperLocations = new Resource[mapperLocationList.size()];
            this.mapperLocations = mapperLocationList.toArray(mapperLocations);

            for(int i = 0; i < this.mapperLocations.length; i++){
                Resource resource = this.mapperLocations[i];
                String url = resource.getFile().toString().replaceAll("target\\\\classes","src\\\\main\\\\resources");
                this.mapperLocations[i] = new FileSystemResource(url);
            }
        }
    }

    @SuppressWarnings("rawtypes")
    private void clearMap(Class<?> classConfig, Configuration configuration, String fieldName) throws Exception {
        Field field = classConfig.getDeclaredField(fieldName);
        field.setAccessible(true);
        Map mapConfig = (Map) field.get(configuration);
        mapConfig.clear();
    }

    @SuppressWarnings("rawtypes")
    private void clearSet(Class<?> classConfig, Configuration configuration, String fieldName) throws Exception {
        Field field = classConfig.getDeclaredField(fieldName);
        field.setAccessible(true);
        Set setConfig = (Set) field.get(configuration);
        setConfig.clear();
    }

    /**
     * 判断文件是否发生了变化
     *
     * @throws IOException
     */
    private boolean isChanged() throws IOException {
        boolean flag = false;
//        System.out.println("***************************获取文件名   开始************************************");
        for (Resource resource : mapperLocations) {
            String resourceName = resource.getFilename();

//            System.out.println("resourceName == " + resourceName+",  path = "+resource.getURL().getPath());

            boolean addFlag = !fileMapping.containsKey(resourceName);// 此为新增标识

            // 修改文件:判断文件内容是否有变化
            Long compareFrame = fileMapping.get(resourceName);
            long lastFrame = resource.contentLength() + resource.lastModified();
            boolean modifyFlag = null != compareFrame && compareFrame.longValue() != lastFrame;// 此为修改标识

            if (addFlag) {
//            	System.out.println("            新增了：==="+ resourceName);
            }
            if (modifyFlag) {
//            	System.out.println("            修改了：==="+ resourceName);
            }

            // 新增或是修改时,存储文件
            if (addFlag || modifyFlag) {
                fileMapping.put(resourceName, Long.valueOf(lastFrame));// 文件内容帧值
                flag = true;
                changeResourceNameList.add(resourceName);
            }
        }
//        System.out.println("***************************获取文件名   结束************************************");
        return flag;
    }
}
