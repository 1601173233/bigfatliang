package com.example.demo.bulider.util;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.example.demo.bulider.model.Column;
import com.example.demo.bulider.model.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.gson.JsonObject;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.util.ReflectionUtils;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * json 解析工具
 *
 * @Author huangyujie
 * @Date 2019/4/18 10:03
 */
public class JsonBuilderUtil {
    static String author;
    static String template;
    static String outPath;
    static boolean isVo;
    static String tablePrefix;
    static String tableComment;

    public static void main(String arg[]) throws IOException, TemplateException {
//        author = "jack.huang";
//        template = "template\\json";
//        outPath = "D:\\code\\jsonBuilder";
//        tablePrefix = "";
//        tableComment = "";
//        isVo = true;
//        if (isVo) {
//            template += "\\vo";
//            outPath += "\\vo";
//        } else {
//            template += "\\dto";
//            outPath += "\\dto";
//        }
//
//        parseJson();

        System.out.println(formatJsonStr(params()));
//        System.out.println(formatJsonStr("{\"orderHeader\":{\"entryOrderCode\":\"SRM2021072200002\",\"ownerCode\":\"btest\",\"purchaseOrderCode\":\"112313131\",\"warehouseCode\":\"btest\",\"orderCreateTime\":\"2021-01-15 18:16:38\",\"orderType\":\"THRK\",\"expectStartTime\":\"2021-05-11 18:16:38\",\"expectEndTime\":\"2021-06-15 18:16:38\",\"logisticsCode\":\"123131\",\"logisticsName\":null,\"expressCode\":\"123123555\",\"supplierCode\":\"btest\",\"supplierName\":null,\"operateTime\":\"2021-03-15 18:16:38\",\"remark\":\"备注\",\"senderInfo\":{\"company\":\"白象收货单位\",\"name\":\"张三\",\"zipCode\":null,\"tel\":\"81784335\",\"mobile\":\"18601234567\",\"email\":null,\"country\":\"中国\",\"province\":\"北京市\",\"city\":\"北京市\",\"area\":\"大兴区\",\"town\":\"亦庄(地区)镇\",\"detailAddress\":\"亦庄\",\"id\":null},\"receiverInfo\":{\"company\":\"白象仓库\",\"name\":\"李四\",\"zipCode\":null,\"tel\":\"81786654\",\"mobile\":\"13129345677\",\"email\":null,\"country\":\"中国\",\"province\":\"北京市\",\"city\":\"北京市\",\"area\":\"大兴区\",\"town\":\"亦庄(地区)镇\",\"detailAddress\":\"亦庄\",\"id\":null},\"orderlines\":[{\"orderLineNo\":\"5\",\"itemCode\":\"11231\",\"itemName\":\"哈哈哈哈哈\",\"brandName\":null,\"inventoryType\":\"ZP\",\"planQty\":\"10\",\"retailPrice\":\"55\",\"actualPrice\":\"80\",\"purchasePrice\":\"12\",\"batchCode\":\"213123\",\"produceCode\":\"3242423\"}]}}"));
    }

    /**
     * 格式化json
     *
     * @param json json数据
     * @return 格式化json
     */
    public static String formatJsonStr(String json) {
        return JSONUtil.formatJsonStr(new JSONObject(json, false, true).toString().replaceAll("\" ", "\""));
    }

    /**
     * json 规整
     * @throws IOException
     * @throws TemplateException
     */
    public static void parseJson() throws IOException, TemplateException {
        String json = params();
        json = json.replace("\n", "").replace("\t", "");
        JSONObject jsonObject = new JSONObject(json, false, true);

        Table mainTable = new Table();
        mainTable.setName(tablePrefix);
        mainTable.setTableCommon(tableComment);
        mainTable.setColumnList(new ArrayList<>());

        List<Table> tableList = new ArrayList<>();
        tableList.add(mainTable);

        parseTableList(jsonObject, mainTable, tableList);

        FreeMarkUtil freeMarkUtil = new FreeMarkUtil();
        freeMarkUtil.init();
        Template temPlate = freeMarkUtil.getTemPlate("json/" + (isVo ? "vo" : "dto"));

        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日");
        String time = simpleDateFormat.format(date);

        for (Table table : tableList) {
            table.setName(StrUtil.upperFirst(table.getName()));
            table.setAuthor(author);
            table.setTime(time);
            freeMarkUtil.outToFile(temPlate, table, outPath,table.getName() + (isVo ? "Vo" : "Dto") + ".java");
        }
    }

    /**
     * 解析成表结构
     *
     * @param jsonObject json对象
     * @param tableList 表结构
     */
    public static void parseTableList(JSONObject jsonObject, Table table, List<Table> tableList) {
        jsonObject.forEach((s, o) -> {
            s = s.indexOf(" ") == 0 ? s.substring(1) : s;

            if (o instanceof JSONArray) {
                if (((JSONArray) o).size() != 0) {
                    Table mTable = new Table();
                    mTable.setColumnList(new ArrayList<>());
                    tableList.add(mTable);
                    setTableName(s, mTable);
                    parseTableList((JSONObject) ((JSONArray) o).get(0), mTable, tableList);

                    // 增加对应的类型
                    Column column = new Column();
                    table.getColumnList().add(column);
                    s = s.replace(" ", "");
                    column.setName(s.substring(0, s.indexOf("(")));

                    String columnComment;
                    if (s.indexOf("(") >= 0) {
                        columnComment = s.substring(s.indexOf("(") + 1, s.length() - 1);
                    } else {
                        columnComment = s;
                    }

                    column.setColumnComment(columnComment);
                    column.setJavaType("List<" + mTable.getName() + ">");
                } else {
                    Column column = new Column();
                    table.getColumnList().add(column);

                    column.setName(s.replace(" ", ""));

                    String columnComment;
                    if (s.indexOf("(") >= 0) {
                        columnComment = s.substring(s.indexOf("(") + 1, s.length() - 1);
                    } else {
                        columnComment = s;
                    }

                    column.setColumnComment(columnComment);
                    column.setJavaType("List<String>");
                }
            } else if (o instanceof JSONObject) {
                Table mTable = new Table();
                mTable.setColumnList(new ArrayList<>());
                tableList.add(mTable);
                setTableName(s, mTable);

                parseTableList((JSONObject) o, mTable, tableList);

                // 增加对应的类型
                Column column = new Column();
                table.getColumnList().add(column);
                s = s.replace(" ", "");
                column.setName(s.substring(0, s.indexOf("(")));
                String columnComment;
                if (s.indexOf("(") >= 0) {
                    columnComment = s.substring(s.indexOf("(") + 1, s.length() - 1);
                } else {
                    columnComment = s;
                }

                column.setColumnComment(columnComment);
                column.setJavaType(mTable.getName());
            } else {
                Column column = new Column();
                table.getColumnList().add(column);

                column.setName(s.replace(" ", ""));
                column.setColumnComment(o.toString());
                column.setJavaType("String");
            }
        });
    }

    /**
     * 获取表名
     *
     * @param name 名称
     * @param table 表结构
     */
    public static void setTableName(String name, Table table) {
        name = name.indexOf(" ") == 0 ? name.substring(1) : name;

        if (name.indexOf("(") >= 0) {
            table.setName(tablePrefix + StrUtil.upperFirst(name.substring(0, name.indexOf("("))));
            table.setTableCommon(tableComment + " - " + name.substring(name.indexOf("(") + 1, name.length() - 1));
        } else {
            table.setName(tablePrefix + StrUtil.upperFirst(name));
            table.setTableCommon(tableComment + " - " + StrUtil.upperFirst(name));
        }
    }

    /**
     * swagger对象转jsonduix
     *
     * @param clazz
     */
    public static void swaggerToJson(Class clazz, JsonObject jsonObject) throws IntrospectionException {
        PropertyDescriptor[] propertyDescriptorArrays = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
        for (PropertyDescriptor propertyDescriptor : propertyDescriptorArrays) {
            //遍历获取属性名
            String name = propertyDescriptor.getName();
            // 增加对自定义注解的判断
            Field declaredField;
            try {
                declaredField = clazz.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                continue;
            }

            ReflectionUtils.makeAccessible(declaredField);
            ApiModelProperty apiModelProperty = declaredField.getAnnotation(ApiModelProperty.class);
            if (apiModelProperty == null) {
                jsonObject.addProperty(declaredField.getName(), "");
            } else {
                if (declaredField.getType() == List.class) {
                    jsonObject.addProperty(declaredField.getName(), apiModelProperty.value());
                } else {
                    jsonObject.addProperty(declaredField.getName(), apiModelProperty.value());
                }
            }
        }
    }

    public static String params() {
        return "{\n" +
                "\"entryOrderCode\":\"入库单号，必填\",\n" +
                "  \"ownerCode\":\"货主编码,必填\",\n" +
                "\"purchaseOrderCode\":\"采购单号\",\n" +
                "\"warehouseCode\":\"仓库编码, ,必填\",\n" +
                "  \"orderCreateTime\":\"订单创建时间\",\n" +
                "\"orderType \":\"业务类型(SCRK=生产入库，LYRK=领用入库，CCRK=残次品入库， CGRK=采购入库，DBRK=调拨入库, QTRK=其他入库，B2BRK=B2B入库,XNRK=虚拟入库)\",\n" +
                "\" expectStartTime \":\"预期到货时间\",\n" +
                "\" expectEndTime \":\"最迟预期到货时间\",\n" +
                "  \" logisticsCode \":\"物流公司编码\",\n" +
                "\" logisticsName \":\"物流公司名称\",\n" +
                "\" expressCode \":\"运单号\",\n" +
                "\" supplierCode \":\"供应商编码\",\n" +
                "\" supplierName \":\"供应商名称\",\n" +
                "\" operateTime \":\"审单时间\",\n" +
                "\" senderInfo(发件人信息)\":{\n" +
                "\" company\":\"公司\",\n" +
                "\" name\":\"姓名\",\n" +
                "\" zipCode\":\"邮编\",\n" +
                "\" tel\":\"固定电话\",\n" +
                "\" mobile\":\"移动电话\",\n" +
                "\" email\":\"电子邮箱\",\n" +
                "\" country\":\"国家\",\n" +
                "\" province\":\"省份\",\n" +
                "\" city\":\"城市\",\n" +
                "\" area\":\"区县\",\n" +
                "\" town\":\"乡镇\",\n" +
                "\" detailAddress\":\"详细地址\",\n" +
                "\" id\":\"证件号\"\n" +
                "},\n" +
                "\" receiverInfo (收件人信息)\":{\n" +
                "\" company\":\"公司\",\n" +
                "\" name\":\"姓名\",\n" +
                "\" zipCode\":\"邮编\",\n" +
                "\" tel\":\"固定电话\",\n" +
                "\" mobile\":\"移动电话\",\n" +
                "\" email\":\"电子邮箱\",\n" +
                "\" country\":\"国家\",\n" +
                "\" province\":\"省份\",\n" +
                "\" city\":\"城市\",\n" +
                "\" area\":\"区县\",\n" +
                "\" town\":\"乡镇\",\n" +
                "\" detailAddress\":\"详细地址\",\n" +
                "\" id\":\"证件号\"\n" +
                "},\n" +
                "\" remark\":\"备注\",\n" +
                "\" orderlines(商品)\":[{\n" +
                "\"orderLineNo\":\"商品行号 ,必填\",\n" +
                "\t\t\"itemCode\":\"商品编码,必填\",\n" +
                "\t\t\"itemName\":\"商品名称,必填\",\n" +
                "\t\t\"brandName\":\"品牌名称\",\n" +
                "\t\t\"inventoryType\":\"库存类型,必填\",\n" +
                "\"planQty\":\"计划数量，必填 \",\n" +
                "\"retailPrice\":\"零售价\",\n" +
                "\t\t\"actualPrice\":\"实际成交价\",\n" +
                "\t\t\"purchasePrice\":\"采购价\",\n" +
                "\t\t\"batchCode\":\"批次编码\",\n" +
                "\t\t\"produceCode\":\"生产批号\",\n" +
                "}]\n" +
                "}\n";
    }

    /**
     * swagger对象转jsonduix
     *
     * @param clazz
     */
    public static void swaggerToJson(Class clazz, JSONObject jsonObject, Set<String> hasAddSet) throws IntrospectionException {
        if (hasAddSet.contains(clazz.getName())) {
            return;
        } else {
            hasAddSet.add(clazz.getName());
        }

        PropertyDescriptor[] propertyDescriptorArrays = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
        for (PropertyDescriptor propertyDescriptor : propertyDescriptorArrays) {
            //遍历获取属性名
            String name = propertyDescriptor.getName();
            // 增加对自定义注解的判断
            Field declaredField;
            try {
                declaredField = clazz.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                continue;
            }

            ReflectionUtils.makeAccessible(declaredField);
            ApiModelProperty apiModelProperty = declaredField.getAnnotation(ApiModelProperty.class);

            JsonIgnore jsonIgnore = declaredField.getAnnotation(JsonIgnore.class);
            if (jsonIgnore != null) {
                continue;
            }

            if (apiModelProperty == null) {
                jsonObject.set(declaredField.getName(), "");
            } else {
                if (Collection.class.isAssignableFrom(declaredField.getType())) {
                    // 泛型类型
                    Type type = ((ParameterizedType) declaredField.getGenericType()).getActualTypeArguments()[0];

                    if (type instanceof ParameterizedType) {
                        if (Map.class.isAssignableFrom((Class<?>) ((ParameterizedType) type).getRawType())) {
                            JSONObject mJsonObject = new JSONObject();
                            mJsonObject.set("类型", "List<Map>");
                            mJsonObject.set("注释", apiModelProperty.value());
                            jsonObject.append(declaredField.getName(), mJsonObject);
                        } else {
                            jsonObject.append(declaredField.getName() + "(类型：未定义处理)", apiModelProperty.value());
                        }
                    }else {
                        if (isDefaultClass((Class<?>) type)) {
                            jsonObject.append(declaredField.getName(), apiModelProperty.value());
                        } else {
                            JSONObject mJsonObject = new JSONObject();
                            swaggerToJson((Class<?>) type, jsonObject, hasAddSet);
                            jsonObject.append(declaredField.getName() + "(" + apiModelProperty.value() + ")", mJsonObject);
                        }
                    }
                } else if (Map.class.isAssignableFrom(declaredField.getType())) {
                    JSONObject mJsonObject = new JSONObject();
                    mJsonObject.set("类型", "Map");
                    mJsonObject.set("注释", apiModelProperty.value());
                    jsonObject.set(declaredField.getName(), mJsonObject);
                } else {
                    if (isDefaultClass(declaredField.getType())) {
                        jsonObject.set(declaredField.getName(), apiModelProperty.value());
                    } else {
                        JSONObject mJsonObject = new JSONObject();
                        swaggerToJson(declaredField.getType(), mJsonObject, hasAddSet);
                        jsonObject.set(declaredField.getName() + "(" + apiModelProperty.value() + ")", mJsonObject);
                    }
                }
            }
        }
    }

    /**
     * 判断是否是常用的java类
     *
     * @param clz
     * @return
     */
    public static boolean isDefaultClass(Class clz) {
        return clz.isPrimitive() || isWrapClass(clz) || clz == String.class;
    }

    /**
     * 判断是否是基础数据类型的包装类型
     *
     * @param clz
     * @return
     */
    public static boolean isWrapClass(Class clz) {
        try {
            return ((Class) clz.getField("TYPE").get(null)).isPrimitive();
        } catch (Exception e) {
            return false;
        }
    }
}
