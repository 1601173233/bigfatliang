package com.example.demo.sql;

import com.example.demo.util.TextIo;

import java.util.StringJoiner;

/**
 * 根据excel内容创造sql
 */
public class CreateSqlByExcel {
    public static void main(String[] args) throws Exception {
        TextIo textIo = new TextIo();
        String s = textIo.input("C:\\Users\\jack.huang\\Desktop\\1.txt");

        String head = "insert into A(";

        int length = (int) (Math.round((s.split("\t", -1).length + 0.0) / s.split("\r\n", -1).length) + 1);
        for (int i = 1; i <= length; i++) {
            head += "A" + i + ",";
        }

        head = head.substring(0, head.length() - 1);

        head += ") values \r\n";

        StringBuilder headBuilder = new StringBuilder(head);
        for (String str : s.split("\r\n", -1)) {
            headBuilder.append("(");
            StringJoiner joiner = new StringJoiner(", ");
            for (String item : str.split("\t", -1)) {
                joiner.add("\"" + item + "\"");
            }

            headBuilder.append(joiner.toString() + "),\r\n");
        }

        TextIo.outPut("C:\\Users\\jack.huang\\Desktop\\2.txt", headBuilder.toString());
    }
}
