
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.json.JSONUtil;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 测试参数生成工具类
 *
 * @author jack.huang
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestParamsUtils {

    /**
     * 获取Token
     */
    public static <T> T createParams(Class<T> c) throws IllegalAccessException, InstantiationException {
        T o = c.newInstance();
        setParams(o);
        return o;
    }

    /**
     * 设置测试的参数
     *
     * @param o 参数
     */
    public static void setParams(Object o) throws IllegalAccessException {
        setParams(o, true);
    }

    /**
     * 设置测试的参数
     *
     * @param o 参数
     * @param ignoreNotEmpty 是否忽略掉非空的字段
     */
    public static void setParams(Object o, Boolean ignoreNotEmpty) throws IllegalAccessException {
        Class<?> c = o.getClass();

        int numberIndex = 0;
        for (Field field : c.getDeclaredFields()) {
            field.setAccessible(true);
            boolean isSetValue = true;

            if (BooleanUtil.isTrue(ignoreNotEmpty) ) {
                Object value = field.get(o);
                if (value != null) {
                    isSetValue = false;
                }
            }

            if (!isSetValue) {
                continue;
            }

            switch (field.getGenericType().getTypeName()) {
                case "java.lang.String" :
                    ApiModelProperty[] annotationsByType = field.getAnnotationsByType(ApiModelProperty.class);
                    if (annotationsByType != null && annotationsByType.length > 0 && StringUtils.isNotEmpty(annotationsByType[0].value())) {
                        field.set(o, annotationsByType[0].value());
                    } else {
                        field.set(o, field.getName());
                    }
                    break;
                case "java.lang.Short" :
                case "java.lang.Integer" :
                    field.set(o, numberIndex++);
                    break;
                case "java.lang.Double" :
                    field.set(o, new Double(numberIndex++));
                    break;
                case "java.lang.Long" :
                    field.set(o, new Long(numberIndex++));
                    break;
                case "java.lang.Boolean" :
                    field.set(o, false);
                    break;
                case "java.util.Date" :
                    field.set(o, new Date());
                    break;
                case "java.time.LocalDateTime" :
                    field.set(o, LocalDateTime.now());
                    break;
                case "java.time.LocalDate" :
                    field.set(o, LocalDate.now());
                    break;
                default:
            }
        }
    }

    public static void main(String arg[]) throws InstantiationException, IllegalAccessException {
        System.out.println(JSONUtil.toJsonStr(createParams(BaseEntity.class)));
    }
}
