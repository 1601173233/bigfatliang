package com.example.demo.excel;

/**
 * excel构造sql
 *
 */
public class ExcelBuildSql {
    public static void main(String[] args) {
        String s = "insert A(a1, a2) values(#{A1}, #{B1});";
        s = "=\"" + s + "\"";
        s = s.replace("#{", "'\"&").replace("}", "&\"'");
        System.out.println(s);
    }
}
