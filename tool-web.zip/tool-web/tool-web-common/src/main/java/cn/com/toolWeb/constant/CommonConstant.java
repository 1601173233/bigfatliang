package cn.com.toolWeb.constant;

/**
 * 静态信息.
 */
public class CommonConstant {
    /**
     * 日志静态参数
     */
    public static interface Log {
        public static String LOG_TRACE_ID = "LOG_TRACE_ID";
    }
}
