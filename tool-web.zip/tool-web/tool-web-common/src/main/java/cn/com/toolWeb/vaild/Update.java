package cn.com.toolWeb.vaild;

/**
 * 校验类型（更新）
 * @author jack.huang
 */
public interface Update {

}
