package com.example.demo.addComment;

import cn.hutool.core.io.FileUtil;
import com.example.demo.util.TextIo;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.util.ReflectionUtils;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 增加注释
 */
public class AddComment {
    private static String clazzPath;
    private static String baseFilePath;
    private static String outPath;

    public static void main(String arg[]) throws Exception {
        // 源码所在路径
        baseFilePath = "D:\\java\\test\\demo\\src\\main\\java\\com\\example\\demo\\addComment\\temp";
        // 源码所在包
        clazzPath = "com.example.demo.addComment.temp";
        // 文件输出地址
        outPath = "D:\\code\\addComment\\";

        addComments(baseFilePath, new File(outPath));
    }

    /**
     * 添加注释
     */
    public static void addComment(Class clazz, String filePath, File outFilePath) throws Exception {
        List<String> javaCode = FileUtil.readLines(filePath, "UTF-8");

        Set<String> commentSet = new HashSet<>();
        addCommentToSet(clazz, commentSet);

        // 处理内部类
        Class innerClazzs[] = clazz.getDeclaredClasses();
        if (innerClazzs != null && innerClazzs.length > 0) {
            for (Class innerClazz : innerClazzs) {
                addCommentToSet(innerClazz, commentSet);
            }
        }

        if (!outFilePath.isDirectory()) {
            outFilePath.mkdirs();
        }

        Writer writer = new FileWriter(outFilePath.getAbsolutePath() + "\\" + clazz.getSimpleName() + ".java");
        for (int index = 0; index < javaCode.size(); index++) {
            String code = javaCode.get(index);
            if (code.indexOf("@ApiModelProperty") > -1 && javaCode.get(index - 1).indexOf("*/") < 0) {
                for (String comment : commentSet) {
                    if (code.indexOf("\"" + comment + "\"") > - 1) {
                        writer.append(code.substring(0, code.indexOf("@ApiModelProperty"))).append("/** ").append(comment).append(" */").append("\r\n");
                        break;
                    }
                }
            }

            writer.append(code).append("\r\n");
        }

        writer.close();
    }

    /**
     * 添加指定类的所有注释
     * @param clazz
     * @param commentSet
     */
    public static void addCommentToSet(Class clazz, Set<String> commentSet) throws IntrospectionException {
        PropertyDescriptor[] propertyDescriptorArrays = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
        for (PropertyDescriptor propertyDescriptor : propertyDescriptorArrays) {
            //遍历获取属性名
            String name = propertyDescriptor.getName();
            // 增加对自定义注解的判断
            Field declaredField;
            try {
                declaredField = clazz.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                continue;
            }

            ReflectionUtils.makeAccessible(declaredField);
            ApiModelProperty apiModelProperty = declaredField.getAnnotation(ApiModelProperty.class);
            if (apiModelProperty == null) {
                continue;
            }

            commentSet.add(apiModelProperty.value());
        }
    }

    /**
     * 添加注释
     */
    public static void addComments(String path, File outFilePath) throws Exception {
        File file = new File(path);
        for (File sonFile : file.listFiles()) {
            if (sonFile.isDirectory()) {
                File dirFile = new File(outFilePath.getAbsolutePath() + "\\" + sonFile.getName());
                addComments(sonFile.getPath(), dirFile);
            } else {
                String clazzPath = path.substring(baseFilePath.length()).replace("\\", ".").replaceAll("/", ".");
                Class clazz = Class.forName(AddComment.clazzPath + clazzPath + "." + sonFile.getName().replace(".java", ""));
                addComment(clazz, sonFile.getAbsolutePath(), outFilePath);
            }
        }
    }
}